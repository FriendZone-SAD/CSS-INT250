<script setup>
import { ref } from 'vue';

defineProps({
    menuItems: {
        type: Array,
        required: true,
    },
});

const isMenuOpen = ref(false);

const toggleMenu = () => {
    isMenuOpen.value = !isMenuOpen.value;
};


</script>

<template>
    <!-- Hero Section -->
    <section
        class="bg-[url(assets/mobile/image-hero.jpg)] bg-no-repeat bg-cover md:bg-[url(assets/desktop/image-hero.jpg)] md:bg-cover">
        <div class="container max-w-6xl mx-auto px-6 py-12">
            <nav class="flex items-center text-white font-bold">
                <img class="w-1/2 mr-auto md:w-1/3" src="../assets/logo.svg" alt="Loopstudios Logo">
                <!-- Menu -->
                <div class="hidden h-10 font-sans ml-auto md:flex md:space-x-8 md:items-center">
                    <div v-for="item in menuItems" :key="item.name" class="group">
                        <a :href="item.link">{{ item.name }}</a>
                        <div class="mx-2 group-hover:border-b group-hover:border-blue-50"></div>
                    </div>
                </div>
                <div class="w-6 ml-auto md:hidden" @click="toggleMenu">
                    <svg viewBox="-0.5 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="#ffffff">
                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                        <g id="SVGRepo_iconCarrier">
                            <path d="M2 12.32H22" stroke="#ffffff" stroke-width="1.5" stroke-linecap="round"
                                stroke-linejoin="round"></path>
                            <path d="M2 18.32H22" stroke="#ffffff" stroke-width="1.5" stroke-linecap="round"
                                stroke-linejoin="round"></path>
                            <path d="M2 6.32001H22" stroke="#ffffff" stroke-width="1.5" stroke-linecap="round"
                                stroke-linejoin="round"></path>
                        </g>
                    </svg>
                </div>
            </nav>
            <div class="mx-2">
                <h1
                    class="text-white border-white border p-3 max-w-[80%] text-4xl font-thin mx-auto mt-20 mb-12 md:max-w-fit md:text-6xl md:p-5 md:ml-0">
                    IMPRESSIVE<br>EXPERIENCES<br>THAT DELIVER</h1>
            </div>
        </div>
    </section>
</template>

<style scope></style>