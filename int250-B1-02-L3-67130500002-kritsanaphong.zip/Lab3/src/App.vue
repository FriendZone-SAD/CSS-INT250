<script setup>
import Counter from './components/Counter.vue'
</script>

<template>
  <Counter />
</template>

<style scoped></style>
